<?php 
	include "database.php";
	include("libs/ImageUploader.php");
	$uploader = new ImageUploader();	//object

	function test_input($data) {
	  $data = trim($data);
	  $data = stripslashes($data);
	  $data = htmlspecialchars($data);
	  $data = str_replace("'", "\'", $data);
	  return $data;
	}
	
	$fields = array(
		"activity_id INT(10) AUTO_INCREMENT PRIMARY KEY",
		"proj_id INT(10)",
		"activity_name VARCHAR(200)",
		"start_date VARCHAR(200)",
		"target_date VARCHAR(200)",
		"finish_date VARCHAR(200)",
		"progress VARCHAR(200)",
	);
	$db->createTable("activity", $fields);
	
	$fields = array(
		"gallery_id INT(10) AUTO_INCREMENT PRIMARY KEY",
		"proj_id INT(10)",
		"activity_id INT(10)",
		"dir VARCHAR(500)",
		"filename VARCHAR(500)",
		"caption VARCHAR(2000)",
	);
	$db->createTable("gallery", $fields);

	$fields = array(
		"prog_id INT(10) AUTO_INCREMENT PRIMARY KEY",
		"activity_id INT(10)",
		"date_checked VARCHAR(200)",
		"progress VARCHAR(200)",
		"remarks VARCHAR(4000)",
	);
	$db->createTable("progress", $fields);

	$activity_id = isset($_POST['activity_id'])?$_POST['activity_id']:"";
	$proj_id = isset($_POST['proj_id'])?$_POST['proj_id']:"";
	$date_checked = isset($_POST['date_checked'])?$_POST['date_checked']:"";
	$remarks = isset($_POST['remarks'])?$_POST['remarks']:"";
	$progress = isset($_POST['progress'])?$_POST['progress']:"";
	if ($progress >= 100) {
		$progress = 100;
	}

	// print_r($_POST);
	$values = array(
		"activity_id"=>$activity_id,
		"date_checked"=>$date_checked,
		"remarks"=>$remarks,
		"progress"=>$progress,
	);
	$result = $db->insertRow("progress",$values);
	$id = $db->getLastId();

	$valuesToUpdate = array(
		"progress"=>$progress,
	);
	$condition=array(
		"activity_id"=>$activity_id,
	);
	$result = $db->updateRows("activity",$valuesToUpdate,$condition);
	if ($progress >= 100) {
		$valuesToUpdate = array(
			"finish_date"=>$date_checked,
		);
		$result = $db->updateRows("activity",$valuesToUpdate,$condition);
	}
	// echo $result;
	// ============================
	// Gallery
	// ============================
	if ($result==0) {
		$stripped_filename = str_replace(" ", "_", $activity_id);
		$stripped_filename = str_replace("'", "_apos_", $stripped_filename);
		$dir = "photos/activity/".$stripped_filename."/"; // directory
		$sizeLimit = 500000000; // filesize limit
		if ($_FILES["img"] && $_FILES["img"]["name"]) {
			$numOfFiles = count($_FILES["img"]["name"]);
			if ($numOfFiles>1) {
				for ($i=0; $i < $numOfFiles; $i++) { 
					$date=date_create();
					$imageFileType = strtolower(pathinfo($_FILES['img']['name'][$i],PATHINFO_EXTENSION)); //change the case of the file extension
					$filename = "gallery_".$stripped_filename."_".date_timestamp_get($date).$i.".".$imageFileType;
					$complete_dir = $dir.$filename;
					$imgFile = array(
						'name'=>$_FILES['img']['name'][$i],
						'type'=>$_FILES['img']['type'][$i],
						'tmp_name'=>$_FILES['img']['tmp_name'][$i],
						'error'=>$_FILES['img']['error'][$i],
						'size'=>$_FILES['img']['size'][$i],
					);
					// upload image
					$result = $uploader->upload($imgFile,"../".$dir,$sizeLimit, $filename);
					if ($result==0) {

						$values = array(
							"proj_id"=> $proj_id*1,
							"activity_id"=> $activity_id*1,
							"filename"=> $filename,
							"dir"=> $dir,
							"caption"=> "",
						);
						$result = $db->insertRow("gallery", $values);
					}
				}

			}else{
				$date=date_create();
				$imageFileType = strtolower(pathinfo($_FILES['img']['name'],PATHINFO_EXTENSION)); //change the case of the file extension
				$filename = "gallery_".$stripped_filename."_".date_timestamp_get($date).".".$imageFileType;
				$complete_dir = $dir.$filename;
				$imgFile = array(
					'name'=>$_FILES['img']['name'],
					'type'=>$_FILES['img']['type'],
					'tmp_name'=>$_FILES['img']['tmp_name'],
					'error'=>$_FILES['img']['error'],
					'size'=>$_FILES['img']['size'],
				);
				// upload image
				$result = $uploader->upload($imgFile,"../".$dir,$sizeLimit, $filename);
				if ($result==0) {

					// update inserted data
					$data_to_update = array(
						"model_img"=> $dir.$filename,
					);
					$condition = array('proj_id'=>$proj_id);
					$result = $db->updateRows("projects", $data_to_update, $condition);
					// 
					
					$values = array(
						"proj_id"=> $proj_id*1,
						"activity_id"=> $activity_id*1,
						"filename"=> $filename,
						"dir"=> $dir,
						"caption"=> "",
					);
					$result = $db->insertRow("gallery", $values);
				}
			}
		}
	}
 	echo $result;
?>