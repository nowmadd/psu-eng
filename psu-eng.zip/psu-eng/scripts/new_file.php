<?php 
	include("database.php");
	include("libs/ImageUploader.php");
	$uploader = new ImageUploader();	//object

	function test_input($data) {
	  $data = trim($data);
	  $data = stripslashes($data);
	  $data = htmlspecialchars($data);
	  $data = str_replace("'", "\'", $data);
	  return $data;
	}
	// print_r($_FILES);
	// print_r($amen
	$tableName = "projects";
	$fields = array(
		"proj_id INT(10) AUTO_INCREMENT PRIMARY KEY",
		"proj_name VARCHAR(30)",
		"start_date VARCHAR(200)",
		"target_date VARCHAR(200)",
		"finish_date VARCHAR(200)",
		"contractor VARCHAR(200)",
		"campus VARCHAR(200)",
		"duration VARCHAR(200)",
		"src_fund VARCHAR(200)",
		"model_img VARCHAR(200)",
		"init_fund VARCHAR(200)",
		"status VARCHAR(200)",
	);
	$db->createTable($tableName, $fields);

	$fields = array(
		"activity_id INT(10) AUTO_INCREMENT PRIMARY KEY",
		"activity_name VARCHAR(200)",
		"proj_id INT(10)",
		"start_date VARCHAR(200)",
		"target_date VARCHAR(200)",
		"finish_date VARCHAR(200)",
		"progress VARCHAR(200)",
	);
	$db->createTable("activity", $fields);

	$fields = array(
		"prog_id INT(10) AUTO_INCREMENT PRIMARY KEY",
		"activity_id INT(10)",
		"date_checked VARCHAR(200)",
		"progress VARCHAR(200)",
		"remarks VARCHAR(4000)",
	);
	$db->createTable("progress", $fields);

	$proj_name = isset($_POST['proj_name'])?test_input($_POST['proj_name']):"default"; 
	$start_date = isset($_POST['start_date'])?test_input($_POST['start_date']):""; 
	$target_date = isset($_POST['target_date'])?test_input($_POST['target_date']):""; 
	$contractor = isset($_POST['contractor'])?test_input($_POST['contractor']):""; 
	$campus = isset($_POST['campus'])?test_input($_POST['campus']):""; 
	$duration = isset($_POST['duration'])?test_input($_POST['duration']):""; 
	$src_fund = isset($_POST['src_fund'])?test_input($_POST['src_fund']):""; 
	$init_fund = isset($_POST['init_fund'])?test_input($_POST['init_fund']):""; 
	$status = isset($_POST['status'])?test_input($_POST['status']):"ongoing"; 

	$values = array(
		"proj_name"=>$proj_name,
		"start_date"=>$start_date,
		"target_date"=>$target_date,
		"contractor"=>$contractor,
		"campus"=>$campus,
		"duration"=>$duration,
		"src_fund"=>$src_fund,
		"init_fund"=>$init_fund,
		"status"=>$status,
	);
	$result = $db->insertRow("projects", $values);

	$proj_id = 0;
	if ($result==0) {
		$proj_id = $db->getLastId() * 1;
		// echo $proj_id;
	}
	// ============================
	// Gallery
	// ============================
	if ($result==0) {
		$stripped_filename = str_replace(" ", "_", $proj_name);
		$stripped_filename = str_replace("'", "_apos_", $stripped_filename);
		$dir = "photos/model/".$stripped_filename."/"; // directory
		$sizeLimit = 500000000; // filesize limit
		if ($_FILES["img"] && $_FILES["img"]["name"]) {
			$numOfFiles = count($_FILES["img"]["name"]);
			if ($numOfFiles>1) {
				for ($i=0; $i < $numOfFiles; $i++) { 
					$date=date_create();
					$imageFileType = strtolower(pathinfo($_FILES['img']['name'][$i],PATHINFO_EXTENSION)); //change the case of the file extension
					$filename = "gallery_".$stripped_filename."_".date_timestamp_get($date).$i.".".$imageFileType;
					$complete_dir = $dir.$filename;
					$imgFile = array(
						'name'=>$_FILES['img']['name'][$i],
						'type'=>$_FILES['img']['type'][$i],
						'tmp_name'=>$_FILES['img']['tmp_name'][$i],
						'error'=>$_FILES['img']['error'][$i],
						'size'=>$_FILES['img']['size'][$i],
					);
					// upload image
					$result = $uploader->upload($imgFile,"../".$dir,$sizeLimit, $filename);
					if ($result==0) {

						// update inserted data
						$data_to_update = array(
							"model_img"=> $dir.$filename,
						);
						$condition = array('proj_id'=>$proj_id);
						$result = $db->updateRows("projects", $data_to_update, $condition);
						// 


						// $values = array(
						// 	"proj_id"=> $proj_id*1,
						// 	"filename"=> $filename,
						// 	"dir"=> $dir,
						// 	"caption"=> "",
						// );
						// $result = $db->insertRow("gallery", $values);
					}
				}

			}else{
				$date=date_create();
				$imageFileType = strtolower(pathinfo($_FILES['img']['name'],PATHINFO_EXTENSION)); //change the case of the file extension
				$filename = "gallery_".$stripped_filename."_".date_timestamp_get($date).".".$imageFileType;
				$complete_dir = $dir.$filename;
				$imgFile = array(
					'name'=>$_FILES['img']['name'],
					'type'=>$_FILES['img']['type'],
					'tmp_name'=>$_FILES['img']['tmp_name'],
					'error'=>$_FILES['img']['error'],
					'size'=>$_FILES['img']['size'],
				);
				// upload image
				$result = $uploader->upload($imgFile,"../".$dir,$sizeLimit, $filename);
				if ($result==0) {

					// update inserted data
					$data_to_update = array(
						"model_img"=> $dir.$filename,
					);
					$condition = array('proj_id'=>$proj_id);
					$result = $db->updateRows("projects", $data_to_update, $condition);
					// 
					
					// $values = array(
					// 	"proj_id"=> $proj_id*1,
					// 	"filename"=> $filename,
					// 	"dir"=> $dir,
					// 	"caption"=> "",
					// );
					// $result = $db->insertRow("gallery", $values);
				}
			}
		}
	}
 	echo $result;
 ?>