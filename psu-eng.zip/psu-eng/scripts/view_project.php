<?php 
	include "database.php";
	include("libs/ImageUploader.php");
	$uploader = new ImageUploader();	//object

	function test_input($data) {
	  $data = trim($data);
	  $data = stripslashes($data);
	  $data = htmlspecialchars($data);
	  $data = str_replace("'", "\'", $data);
	  return $data;
	}
	
	$fields = array(
		"prog_id INT(10) AUTO_INCREMENT PRIMARY KEY",
		"activity_id INT(10)",
		"proj_id INT(10)",
		"date_checked VARCHAR(200)",
		"progress VARCHAR(200)",
		"remarks VARCHAR(4000)",
	);
	$db->createTable("progress", $fields);

	$fields = array(
		"activity_id INT(10) AUTO_INCREMENT PRIMARY KEY",
		"proj_id INT(10)",
		"activity_name VARCHAR(200)",
		"start_date VARCHAR(200)",
		"target_date VARCHAR(200)",
		"finish_date VARCHAR(200)",
		"progress VARCHAR(200)",
	);
	$db->createTable("activity", $fields);

	$fields = array(
		"gallery_id INT(10) AUTO_INCREMENT PRIMARY KEY",
		"proj_id INT(10)",
		"activity_id INT(10)",
		"dir VARCHAR(500)",
		"filename VARCHAR(500)",
		"caption VARCHAR(2000)",
	);
	$db->createTable("gallery", $fields);
	
	$proj_id = isset($_POST['proj_id'])?test_input($_POST['proj_id']):""; 
	$activity_name = isset($_POST['activity_name'])?test_input($_POST['activity_name']):""; 
	$start_date = isset($_POST['start_date'])?test_input($_POST['start_date']):""; 
	$target_date = isset($_POST['target_date'])?test_input($_POST['target_date']):""; 
	$finish_date = isset($_POST['finish_date'])?test_input($_POST['finish_date']):""; 
	$progress = isset($_POST['progress'])?test_input($_POST['progress']):0; 

	$values = array(
		"activity_name"=>$activity_name,
		"proj_id"=>$proj_id,
		"start_date"=>$start_date,
		"target_date"=>$target_date,
		"finish_date"=>$finish_date,
		"progress"=>$progress,
	);
	// print_r($values);
	$result = $db->insertRow("activity", $values);
	$activity_id = $db->getLastId();
	echo "activity_id ".$activity_id;

	// ============================
	// Gallery
	// ============================
	if ($result==0) {
		$stripped_filename = str_replace(" ", "_", $activity_id);
		$stripped_filename = str_replace("'", "_apos_", $stripped_filename);
		$dir = "photos/activity/".$stripped_filename."/"; // directory
		$sizeLimit = 500000000; // filesize limit
		if ($_FILES["img"] && $_FILES["img"]["name"]) {
			$numOfFiles = count($_FILES["img"]["name"]);
			if ($numOfFiles>1) {
				for ($i=0; $i < $numOfFiles; $i++) { 
					$date=date_create();
					$imageFileType = strtolower(pathinfo($_FILES['img']['name'][$i],PATHINFO_EXTENSION)); //change the case of the file extension
					$filename = "gallery_".$stripped_filename."_".date_timestamp_get($date).$i.".".$imageFileType;
					$complete_dir = $dir.$filename;
					$imgFile = array(
						'name'=>$_FILES['img']['name'][$i],
						'type'=>$_FILES['img']['type'][$i],
						'tmp_name'=>$_FILES['img']['tmp_name'][$i],
						'error'=>$_FILES['img']['error'][$i],
						'size'=>$_FILES['img']['size'][$i],
					);
					// upload image
					$result = $uploader->upload($imgFile,"../".$dir,$sizeLimit, $filename);
					if ($result==0) {

						$values = array(
							"proj_id"=> $proj_id*1,
							"activity_id"=> $activity_id*1,
							"filename"=> $filename,
							"dir"=> $dir,
							"caption"=> "",
						);
						$result = $db->insertRow("gallery", $values);
					}
				}

			}else{
				$date=date_create();
				$imageFileType = strtolower(pathinfo($_FILES['img']['name'],PATHINFO_EXTENSION)); //change the case of the file extension
				$filename = "gallery_".$stripped_filename."_".date_timestamp_get($date).".".$imageFileType;
				$complete_dir = $dir.$filename;
				$imgFile = array(
					'name'=>$_FILES['img']['name'],
					'type'=>$_FILES['img']['type'],
					'tmp_name'=>$_FILES['img']['tmp_name'],
					'error'=>$_FILES['img']['error'],
					'size'=>$_FILES['img']['size'],
				);
				// upload image
				$result = $uploader->upload($imgFile,"../".$dir,$sizeLimit, $filename);
				if ($result==0) {

					$values = array(
						"proj_id"=> $proj_id*1,
						"activity_id"=> $activity_id*1,
						"filename"=> $filename,
						"dir"=> $dir,
						"caption"=> "",
					);
					print_r($values);
					$result = $db->insertRow("gallery", $values);
				}
			}
		}
	}
	echo $result;
 ?>