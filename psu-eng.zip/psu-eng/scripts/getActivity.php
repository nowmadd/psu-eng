<?php 
	include "database.php";
	
	function test_input($data) {
	  $data = trim($data);
	  $data = stripslashes($data);
	  $data = htmlspecialchars($data);
	  $data = str_replace("'", "\'", $data);
	  return $data;
	}

	$fields = array(
		"activity_id INT(10) AUTO_INCREMENT PRIMARY KEY",
		"proj_id INT(10)",
		"activity_name VARCHAR(200)",
		"start_date VARCHAR(200)",
		"target_date VARCHAR(200)",
		"finish_date VARCHAR(200)",
		"progress VARCHAR(200)",
	);
	$db->createTable("activity", $fields);

	$proj_id = isset($_POST['proj_id'])?test_input($_POST['proj_id']):""; 
	$result = $db->customSelectQuery("SELECT * FROM activity WHERE proj_id=".$proj_id." ORDER BY activity_id DESC");
	if (count($result)>0) {
		for ($i=0; $i < count($result); $i++) { 
			$activity_id = $result[$i]['activity_id'];
			$result[$i]['gallery'] = $db->customSelectQuery("SELECT * FROM gallery WHERE activity_id=".$activity_id." ORDER BY gallery_id ASC");
			$result[$i]['progress_updates'] = $db->customSelectQuery("SELECT * FROM progress WHERE activity_id=".$activity_id);
		}
	}
	// print_r($result);
	if (count($result)>0) {
		echo json_encode($result);
	}else{
		echo 1;
	}

?>