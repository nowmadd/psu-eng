<?php 
	include "database.php";
	
	function test_input($data) {
	  $data = trim($data);
	  $data = stripslashes($data);
	  $data = htmlspecialchars($data);
	  $data = str_replace("'", "\'", $data);
	  return $data;
	}
	$tableName = "accounts";
	$fields = array(
		"account_id INT(10) AUTO_INCREMENT PRIMARY KEY",
		"username VARCHAR(30)",
		"password VARCHAR(100)",
		"f_name VARCHAR(100)",
		"m_name VARCHAR(100)",
		"l_name VARCHAR(100)",
		"campus VARCHAR(100)",
		"type VARCHAR(100)",
	);
	$db->createTable($tableName, $fields);

	$search = isset($_POST['search'])?test_input($_POST['search']):""; 
	$result = $db->customSelectQuery("SELECT * FROM accounts WHERE f_name LIKE '%".$search."%' or m_name LIKE '%".$search."%' or l_name LIKE '%".$search."%'");
	if (count($result)>0) {
		echo json_encode($result);
	}else{
		echo 1;
	}

?>