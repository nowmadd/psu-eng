<?php 
	include "database.php";
	
	function test_input($data) {
	  $data = trim($data);
	  $data = stripslashes($data);
	  $data = htmlspecialchars($data);
	  $data = str_replace("'", "\'", $data);
	  return $data;
	}
	
	$tableName = "accounts";
	$fields = array(
		"account_id INT(10) AUTO_INCREMENT PRIMARY KEY",
		"username VARCHAR(30)",
		"password VARCHAR(100)",
		"f_name VARCHAR(100)",
		"m_name VARCHAR(100)",
		"l_name VARCHAR(100)",
		"campus VARCHAR(100)",
		"type VARCHAR(100)",
	);
	$db->createTable($tableName, $fields);

	$account_id = isset($_POST['account_id'])?test_input($_POST['account_id']):""; 
	$result = $db->execute("DELETE FROM accounts WHERE account_id=".$account_id);
	if (count($result)>0) {
		echo 0;
	}else{
		echo 1;
	}

?>