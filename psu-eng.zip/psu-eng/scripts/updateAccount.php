<?php 
	include "database.php";
	
	function test_input($data) {
	  $data = trim($data);
	  $data = stripslashes($data);
	  $data = htmlspecialchars($data);
	  $data = str_replace("'", "\'", $data);
	  return $data;
	}
	
	$tableName = "accounts";
	$fields = array(
		"account_id INT(10) AUTO_INCREMENT PRIMARY KEY",
		"username VARCHAR(30)",
		"password VARCHAR(100)",
		"f_name VARCHAR(100)",
		"m_name VARCHAR(100)",
		"l_name VARCHAR(100)",
		"campus VARCHAR(100)",
		"type VARCHAR(100)",
	);
	$db->createTable($tableName, $fields);

	print_r($_POST);

	$account_id = isset($_POST['account_id'])?test_input($_POST['account_id']):""; 
	$username = isset($_POST['username'])?test_input($_POST['username']):""; 
	$f_name = isset($_POST['f_name'])?test_input($_POST['f_name']):""; 
	$m_name = isset($_POST['m_name'])?test_input($_POST['m_name']):""; 
	$l_name = isset($_POST['l_name'])?test_input($_POST['l_name']):""; 
	$campus = isset($_POST['campus'])?test_input($_POST['campus']):""; 
	$type = isset($_POST['type'])?test_input($_POST['type']):""; 

	$data_to_update = array(
		"username"=> $username,
		"f_name"=> $f_name,
		"m_name"=> $m_name,
		"l_name"=> $l_name,
		"campus"=> $campus,
		"type"=> $type,
	);
	$condition = array('account_id'=>$account_id);
	$result = $db->updateRows($tableName, $data_to_update, $condition);
	echo $result;
?>