<?php 
	include "database.php";
	
	function test_input($data) {
	  $data = trim($data);
	  $data = stripslashes($data);
	  $data = htmlspecialchars($data);
	  $data = str_replace("'", "\'", $data);
	  return $data;
	}
	
	$fields = array(
		"activity_id INT(10) AUTO_INCREMENT PRIMARY KEY",
		"proj_id INT(10)",
		"activity_name VARCHAR(200)",
		"start_date VARCHAR(200)",
		"target_date VARCHAR(200)",
		"finish_date VARCHAR(200)",
		"progress VARCHAR(200)",
	);
	$db->createTable("activity", $fields);

	$activity_id = isset($_POST['activity_id'])?test_input($_POST['activity_id']):""; 

	$result = $db->execute("DELETE FROM activity WHERE activity_id=".$activity_id);
	if (count($result)>0) {
		echo 0;
	}else{
		echo 1;
	}

?>