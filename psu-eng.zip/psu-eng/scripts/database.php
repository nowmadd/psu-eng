<?php 

	header('Access-Control-Allow-Origin: *');
	header('Access-Control-Allow-Methods: GET, POST');
	
	require("libs/dbHelper.php");
	$db = new DBHelper(); 
	// $db->setDebugOn();

	$servername = "localhost";
	$username = "root";
	$password = "";

	// $servername = "localhost";
	// $username = "id8168159_psu_eng";
	// $password = "arj0r13W3bh0st";

	$db->connect($servername,$username,$password);

	$db->execute("USE db_eng;");

?>