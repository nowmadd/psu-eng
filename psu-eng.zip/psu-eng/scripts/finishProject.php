<?php 
	include "database.php";
	
	function test_input($data) {
	  $data = trim($data);
	  $data = stripslashes($data);
	  $data = htmlspecialchars($data);
	  $data = str_replace("'", "\'", $data);
	  return $data;
	}
	print_r($_POST);
	$proj_id = isset($_POST['proj_id'])?test_input($_POST['proj_id']):""; 
	$finish_date = isset($_POST['finish_date'])?test_input($_POST['finish_date']):""; 
	$result = $db->execute("UPDATE projects SET status='finished', finish_date = '".$finish_date."' WHERE proj_id=".$proj_id);
	echo $result;
?>