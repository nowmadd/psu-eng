<?php 
	include "database.php";
	
	$tableName = "projects";
	$fields = array(
		"proj_id INT(10) AUTO_INCREMENT PRIMARY KEY",
		"proj_name VARCHAR(30)",
		"start_date VARCHAR(100)",
		"target_date VARCHAR(100)",
		"finish_date VARCHAR(100)",
		"contractor VARCHAR(100)",
		"campus VARCHAR(100)",
		"duration VARCHAR(100)",
		"src_fund VARCHAR(100)",
		"model_img VARCHAR(100)",
		"init_fund VARCHAR(100)",
		"status VARCHAR(100)",
	);
	$db->createTable($tableName, $fields);

	$fields = array(
		"prog_id INT(10) AUTO_INCREMENT PRIMARY KEY",
		"activity_id INT(10)",
		"proj_id INT(10)",
		"date_checked VARCHAR(200)",
		"progress VARCHAR(200)",
		"remarks VARCHAR(4000)",
	);
	$db->createTable("progress", $fields);

	$fields = array(
		"activity_id INT(10) AUTO_INCREMENT PRIMARY KEY",
		"proj_id INT(10)",
		"start_date VARCHAR(200)",
		"activity_name VARCHAR(200)",
		"target_date VARCHAR(200)",
		"finish_date VARCHAR(200)",
		"progress VARCHAR(200)",
	);
	$db->createTable("activity", $fields);
	$proj_id = isset($_POST['proj_id'])?$_POST['proj_id']:0;


	$data = $db->customSelectQuery("SELECT * FROM projects WHERE proj_id=".$proj_id);
	// print_r($data);
	if (count($data)>0) {
		for ($i=0; $i < count($data) ; $i++) { 
			$totalProgress = 0;
			$proj_id = $data[$i]['proj_id']?$data[$i]['proj_id']:0;
			// $data[$i]['progress'] = 
			$tmpProg = $db->customSelectQuery("SELECT progress FROM activity WHERE proj_id=".$proj_id);
			// print_r($tmpProg);
			if (count($tmpProg)>0) {
				for ($j=0; $j < count($tmpProg); $j++) { 
					// print_r($tmpProg);
					$totalProgress = $totalProgress + $tmpProg[$j]['progress'];
				}
			}
			// echo $totalProgress/2;
			if ( count($tmpProg)==0) {
				$data[$i]["progress"] = 0;
			}else{
				$data[$i]["progress"] = $totalProgress / count($tmpProg);
			}
		}
	}
	echo json_encode($data);
 ?>