<?php 
	include "database.php";
	
	$tableName = "accounts";
	$fields = array(
		"account_id INT(10) AUTO_INCREMENT PRIMARY KEY",
		"username VARCHAR(30)",
		"password VARCHAR(100)",
		"f_name VARCHAR(100)",
		"m_name VARCHAR(100)",
		"l_name VARCHAR(100)",
		"campus VARCHAR(100)",
		"type VARCHAR(100)",
	);
	$db->createTable($tableName, $fields);
	$result = $db->getAllRows($tableName);
	if (count($result)>0) {
		echo json_encode($result);
	}else{
		echo 1;
	}

?>