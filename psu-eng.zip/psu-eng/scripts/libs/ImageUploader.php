<?php 
	/**
	* 
	*/
	class ImageUploader
	{
		private $successCounts=0;
		private $errorCounts=0;

		function onSuccess(){
			return $this->successCounts;
		}
		function onError(){
			return $this->errorCounts;
		}

		function process($imgFile, $dir, $sizeLimit, $filename){
			$target_dir = $this->dir; //create dir for the intended user
			$defaultFilename = isset($filename)?$filename."":basename($imgFile["name"]);
			$target_file = $target_dir . $defaultFilename; // the complete directory
			$this->target_file = $target_file;
			$errorCode = 0;
			// echo "\n"."<br>$target_dir";
			// echo "\n"."<br>$target_file";
			// echo "\n"."<br>$dir";
			// echo "\n"."<br>$sizeLimit";
			// echo "\n"."<br>$filename";
			// echo "\n"."$target_file";
			$uploadOk = 1; // flag
			$imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION)); //change the case of the file extension
			
			// Check if image file is a actual image or fake image
		    $check = getimagesize($imgFile["tmp_name"]);
		    if($check !== false) {
		        // echo "\n"."<br>File is an image - " . $check["mime"] . "<br>";
		        $uploadOk = 1;
		    } else {
		        // echo "\n"."File is not an image.";
		        $uploadOk = 0;
				return 1;
		    }

			// Check if file already exists
			if (file_exists($target_file)) {
			    // echo "\n"."Sorry, file already exists.";
			    $uploadOk = 0;
				return 2;
			}else {
				if (is_dir($target_dir)) {
					// echo "\n"."is a directory";
				    // echo "\n"."Success";
				}else{
					// echo "\n"."<br>no such directory <br>";
				    mkdir($target_dir, 0777, true);
				}
			}

			// Check file size
			if ($imgFile["size"] > $sizeLimit) {
			    // echo "\n"."Sorry, your file is too large.";
			    $uploadOk = 0;
				return 3;
			}

			// Allow certain file formats
			if(strtolower($imageFileType) != "jpg" && strtolower($imageFileType) != "png" && strtolower($imageFileType) != "jpeg"
			&& strtolower($imageFileType) != "gif" ) {
				// echo "\n".$imageFileType;
			    // echo "\n"."Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
			    $uploadOk = 0;
			return 1;
			}

			// Check if $uploadOk is set to 0 by an error
			if ($uploadOk == 0) {
			    // echo "\n"."Sorry, your file was not uploaded.";
			// if everything is ok, try to upload file
			} else {
				// echo "\n".$imgFile["tmp_name"];
			    if (move_uploaded_file($imgFile["tmp_name"], $target_file)) { //uploads the image
			        // echo "\n"."The file ". basename( $imgFile["name"]). " has been uploaded.";
			    	return 0;
			    } else {
			        // echo "\n"."Sorry, there was an error uploading your file.";
			    	return $errorCode;
			    }
			}
		}
		private function getUrl(){
			return $this->target_file;
		}

		function upload($file, $dir, $sizeLimit, $filename){
			$this->dir = isset($dir)?$dir:"img/";
			$this->sizeLimit = isset($sizeLimit)?$sizeLimit:500000;
			$this->file = $file;
			$this->filename = isset($filename)?$filename:"default.png";
			if ($this->filename=="") {
				return 7;
			}
			// echo "\n".json_encode($file);
			$imgFile = array(
				'name'=>$file['name'],
				'type'=>$file['type'],
				'tmp_name'=>$file['tmp_name'],
				'error'=>$file['error'],
				'size'=>$file['size'],
			);
			$result = $this->process($imgFile, $this->dir, $this->sizeLimit, $filename);
			if ($result==0) {
				$this->successCounts++;
			}else{
				$this->errorCounts++;
			}
			return $result;
		}

	}


?>