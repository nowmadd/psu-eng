<?php 

    /**
    * Database Helper class 
    */
    class DBHelper
    {
        private $conn;
        private $debugMode = "false";


        // ==============================================
        // UTILITY FUNCTIONS
        // ==============================================


        function setDebugOn(){
            $this->debugMode = "true";
        }

        private function printLn($message){
            if ($this->debugMode==="true") {
                echo "<br>";
                if (gettype($message)=="string") {
                    echo $message;
                }elseif(gettype($message)=="array"){
                    print_r($message);
                }
            }
        } 

        private function prepareDataToUpdate($data_to_update){
            $dataToUpdate = "";
            $count = 0;
            if (isset($data_to_update) and gettype($data_to_update)=="array") {
                foreach($data_to_update as $key => $value) {
                    $dataType = gettype($value);
                    if (0==$count) {
                        if ($dataType=="string") {
                            $dataToUpdate = $key."='".$value."'";
                        }elseif($dataType=="integer"){
                            $dataToUpdate = $key."=".$value;
                        }
                    }else{
                        if ($dataType=="string") {
                            $dataToUpdate = $dataToUpdate.", ".$key."='".$value."'";
                        }elseif($dataType=="integer"){
                            $dataToUpdate = $dataToUpdate.", ".$key."=".$value."";
                        }
                    }
                    $count= $count + 1;
                }
            }
            return $dataToUpdate;
        }

        private function formatConditions($conditions){
            $count = 0;
            $condition = "";
            if (isset($conditions) and gettype($conditions)=="array") {
                foreach($conditions as $key => $value) {
                    $dataType = gettype($value);
                    if (0==$count) {
                        if ($dataType=="string") {
                            $condition = $key."='".$value."'";
                        }elseif($dataType=="integer"){
                            $condition = $key."=".$value;
                        }
                    }else{
                        if ($dataType=="string") {
                            $condition = $condition." and ".$key."='".$value."'";
                        }elseif($dataType=="integer"){
                            $condition = $condition." and ".$key."=".$value."";
                        }
                    }
                    $count= $count + 1;
                }
            }
            return $condition;
        }

        private function formatValue($values){
            $keys = "";
            $valueToInsert = "";
            $count = 0;
            foreach($values as $key => $value) {
                $dataType = gettype($value);
                if (0==$count) {
                    $keys = $key;
                    if ($dataType=="string") {
                        $valueToInsert = "'".$value."'";
                    }elseif($dataType=="integer"){
                        $valueToInsert = $value;
                    }
                }else{
                    $keys = $keys.", ".$key;
                    if ($dataType=="string") {
                        $valueToInsert = $valueToInsert.", '".$value."'";
                    }elseif($dataType=="integer"){
                        $valueToInsert = $valueToInsert.", ".$value;
                    }
                }
                $count= $count + 1;
            }
            $keyValues = array("keys"=>$keys,"values"=>$valueToInsert);
            return $keyValues;
        }

        private function prepareExecuteFetch($tablename, $conditions){
            $sql = "";
            if (gettype($conditions)=="array") {
                $condition = $this->formatConditions($conditions);
                if ($condition=="") {
                    $sql = "SELECT * FROM ".$tablename.";";
                }else{
                    $sql = "SELECT * FROM ".$tablename." where ".$condition.";";
                }
            }elseif (gettype($conditions)=="string" && ($conditions=="")){
                $sql = "SELECT * FROM ".$tablename.";";
            }
            $stmt = $this->conn->prepare($sql); 
            $data = array();
            try {
                $stmt->execute();

                // set the resulting array to associative
                $data = $stmt->setFetchMode(PDO::FETCH_ASSOC); 
                $data = $stmt->fetchAll();
                $this->printLn("$sql");
            } catch (Exception $e) {
                $this->printLn("Database, Table or Column doesn't exist!");
            }
            return $data;
        }
        
        // ==============================================
        // MAIN FUNCTIONS
        // ==============================================

        function connect($server, $username, $password){
            try {
                $dbname="";
                $this->printLn("Connecting...");
                $this->conn = new PDO("mysql:host=$server;dbname=$dbname;", $username, $password);
                 // set the PDO error mode to exception
                $this->conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                $this->printLn("Connected successfully");
                return $this->conn; 
            } catch (Exception $e) {
                $this->printLn("Connection failed: " . $e->getMessage());
                return 0;
            }
        }      

        function createDB($dbname){
            $result = 0;
            try {
                $this->printLn("===========================================");
                $this->printLn("Searching for database [".$dbname."]");
                $this->printLn("------------------------------------------");
                $stmt = $this->conn->prepare("SHOW DATABASES;"); //prepare sql command
                $stmt->execute(); //executes the prepared sql command
                $stmt->setFetchMode(PDO::FETCH_ASSOC); //sets the fetch mode to associative arrays
                $rows = $stmt->fetchAll(); // fetches all data
                // loop and show results
                for ($i=0; $i < count($rows); $i++) { 
                     foreach($rows[$i] as $k=>$v) { 
                        if (strtolower($dbname)===strtolower($v)) {
                            $result = 1;
                            break;
                        }
                    }
                }

                if ($result===0) { //if not exists
                    $this->printLn("Database doesnt exists");
                    $this->printLn("Creating database");
                    $stmt = $this->conn->prepare("CREATE DATABASE ".$dbname.";"); // create db
                    $stmt->execute(); // create db
                }else{
                    $this->printLn("Database exists");
                }
                // use database
                $this->printLn("Using database [".$dbname."] as default schema");
                $this->conn->exec("USE ".$dbname.";"); //

            } catch (PDOExeption $e) {
                $this->printLn($e);
                return 0;
            }
            return $result;
        }  

        function dropDB($dbname){
            $result = 0;
            try {
                $this->printLn("===========================================");
                $this->printLn("Searching for database [".$dbname."]");
                $this->printLn("------------------------------------------");
                $stmt = $this->conn->prepare("SHOW DATABASES;"); //prepare sql command
                $stmt->execute(); //executes the prepared sql command
                $stmt->setFetchMode(PDO::FETCH_ASSOC); //sets the fetch mode to associative arrays
                $rows = $stmt->fetchAll(); // fetches all data
                // loop and show results
                for ($i=0; $i < count($rows); $i++) { 
                     foreach($rows[$i] as $k=>$v) { 
                        if (strtolower($dbname)===strtolower($v)) {
                            $result = 1;
                        }
                    }
                }

                if ($result===0) { //if not exists
                    $this->printLn("Database doesn't exists");
                    $result = 1;
                }else{
                    $this->printLn("Database exists");
                    $this->conn->exec("USE ".$dbname.";"); // use 'freedom_wall_db' database
                    $this->conn->exec("DROP DATABASE ".$dbname.";"); // create db
                    $this->printLn("Successfully dropped!");
                    $result = 0;
                }

            } catch (PDOExeption $e) {
                $this->printLn($e);
                return 1;
            }
            return $result;
        }

        function createTable($tablename, $fields){
            $result = 0;
            try {
                $this->printLn("===========================================");
                $this->printLn("Creating table if not exists [".$tablename."]");
                $this->printLn("------------------------------------------");
                $str = "";
                for ($i=0; $i < count($fields); $i++) { 
                    if (count($fields)-1==$i) {
                        $str = $str.$fields[$i];
                    }else{
                        $str = $str.$fields[$i].", ";
                    }
                }
                $sql = "CREATE TABLE IF NOT EXISTS ".$tablename." (".$str.");";
                $this->conn->exec($sql);
                $this->printLn("$sql");
                $this->printLn("Table created successfully!");
            } catch (PDOExeption $e) {
                $this->printLn($e);
                $result = 1;
            }
            return $result;
        }

        function dropTable($tablename){
            $result = 0;
            $this->printLn("===========================================");
            $this->printLn("Dropping table if exists [".$tablename."]");
            $this->printLn("------------------------------------------");

            $stmt = $this->conn->prepare("SHOW TABLES;"); //prepare sql command
            $stmt->execute(); //executes the prepared sql command
            $stmt->setFetchMode(PDO::FETCH_ASSOC); //sets the fetch mode to associative arrays
            $rows = $stmt->fetchAll(); // fetches all data
            // loop and show results
            for ($i=0; $i < count($rows); $i++) { 
                 foreach($rows[$i] as $k=>$v) { 
                    if (strtolower($tablename)===strtolower($v)) {
                        $result = 1;
                        break;
                    }
                }
            }

            if ($result===0) { //if not exists
                $this->printLn("Table doesnt exists");
            }else{
                try {
                    $sql = "DROP TABLE ".$tablename.";";
                    $result = 0;
                    $this->conn->exec($sql);
                    $this->printLn("$sql");
                    $this->printLn("Table dropped successfully!");
                } catch (PDOExeption $e) {
                    $this->printLn($e);
                    $result = 1;
                }
            }

            return $result;
        }

        function insertRow($tablename, $values){
            $result = 0;
            $this->printLn("===========================================");
            $this->printLn("inserting a row to the table [".$tablename."]");
            $this->printLn("------------------------------------------");
            $keyValues = $this->formatValue($values);
            $keys = $keyValues["keys"];
            $valueToInsert = $keyValues["values"];
            $sql = "INSERT INTO ".$tablename." (".$keys.") VALUES (".$valueToInsert.");";
            $this->printLn("$sql");
            try {
                $this->conn->exec($sql);
                $this->printLn("Data inserted successfully!");
            } catch (Exception $e) {
                $this->printLn("Database, Table or Column doesn't exist!".$e);       
                $result = 1;
            }
            return $result;
        }

        function deleteRows($tablename,$conditions){
            $result = 0;
            try {
                $this->printLn("===========================================");
                $this->printLn("Deleting a row from table [".$tablename."]");
                $this->printLn("------------------------------------------");
                $condition = $this->formatConditions($conditions);
                if ($condition!=""){
                    $sql = "DELETE FROM ".$tablename." where ".$condition.";";
                    $this->conn->exec($sql);
                    $this->printLn("$sql");
                    $data = $this->prepareExecuteFetch($tablename, $conditions);
                    $dataCount = count($data);
                    if ($dataCount==0) {
                        $this->printLn("Record not existing!");
                        $result = 1;
                    }else{
                        $this->printLn("successfully deleted!");
                    }
                }
            } catch (PDOExeption $e) {
                $this->printLn($e);
                $result = 1;
            }
            return $result;
        }

        function deleteAll($tablename){
            $result = 0;
            try {
                $this->printLn("===========================================");
                $this->printLn("Deleting all rows from table [".$tablename."]");
                $this->printLn("------------------------------------------");
                    if (isset($tablename)) {
                        $sql = "DELETE FROM ".$tablename.";";
                        $this->conn->exec($sql);
                        $this->printLn("$sql");
                        $this->printLn("successfully deleted all data!");
                    }
                }
            catch (PDOExeption $e) {
                $this->printLn($e);
                $result = 1;
            }
            return $result;
        }

        function updateRows($tablename, $data_to_update, $conditions){
            $result = 1;
            try {
                $this->printLn("===========================================");
                $this->printLn("Updating a row from table [".$tablename."]");
                $this->printLn("------------------------------------------");
                $data = $this->getRows($tablename, $conditions);
                if (count($data)>0) {
                    $condition = $this->formatConditions($conditions);
                    $update_data = $this->prepareDataToUpdate($data_to_update);
                    $sql="";
                    if ($condition!="") {
                        $sql = "UPDATE ".$tablename." SET ".$update_data." Where ".$condition;
                    }else{
                        $sql = "UPDATE ".$tablename." SET ".$update_data;
                    }
                    $this->printLn("$sql");
                     // Prepare statement
                    $stmt = $this->conn->prepare($sql);
                    // execute the query
                    $stmt->execute();
                    $this->printLn("Successfully updated!");
                    $result = 0;
                }else{
                    $this->printLn("No record(s) found to update!");
                    $result = 1;
                }
            } catch (PDOExeption $e) {
                $this->printLn($e);
            }
            return $result;
        }

        function getRows($tablename, $conditions){
            $data = array();
            $sql = "";
            $this->printLn("===========================================");
            $this->printLn("Retrieving some data from database [".$tablename."]");
            $this->printLn("------------------------------------------");
            $data = $this->prepareExecuteFetch($tablename, $conditions);
            $dataCount = count($data);        
            if ($dataCount==0) {
                $this->printLn("No records!");
            }else{
                $this->printLn("record count ".$dataCount);
                $this->printLn("Successfully retrieved data!");
            }
            return $data;
        }

        function getAllRows($tablename){
            $data = array();
            $sql = "";
            $this->printLn("===========================================");
            $this->printLn("Retrieving all data from table [".$tablename."]");
            $this->printLn("------------------------------------------");
            $data = $this->prepareExecuteFetch($tablename, "");
            $dataCount = count($data);        
            if ($dataCount==0) {
                $this->printLn("No records!");
            }else{
                $this->printLn("record count ".$dataCount);
                $this->printLn("Successfully retrieved data!");
            }
            return $data;
        }

        function getRowsAsJSON($tablename, $conditions){
            $data = array();
            $sql = "";
            $this->printLn("===========================================");
            $this->printLn("Retrieving some data as JSON from table [".$tablename."]");
            $this->printLn("------------------------------------------");
            $data = $this->prepareExecuteFetch($tablename, $conditions);
            $dataCount = count($data);        
            if ($dataCount==0) {
                $this->printLn("No records!");
            }else{
                $this->printLn("record count ".$dataCount);
                $this->printLn("Successfully retrieved data!");
            }
            return $data;
        }

        function getAllRowsAsJSON($tablename){
            $data = array();
            $sql = "";
            $this->printLn("===========================================");
            $this->printLn("Retrieving all data as JSON from table [".$tablename."]");
            $this->printLn("------------------------------------------");
            $data = $this->prepareExecuteFetch($tablename, "");
            $dataCount = count($data);        
            if ($dataCount==0) {
                $this->printLn("No records!");
            }else{
                $this->printLn("record count ".$dataCount);
                $this->printLn("Successfully retrieved data!");
            }
            $data = json_encode($data);
            return $data;
        }

        function searchRows($tablename, $field, $value){
            $data = array();
            $sql = "";
            $this->printLn("===========================================");
            $this->printLn("Searching some data from database [".$tablename."]");
            $this->printLn("------------------------------------------");

            $sql = "";
            $sql = "SELECT * FROM ".$tablename." WHERE ".$field." LIKE "." '".$value."%'";
            $stmt = $this->conn->prepare($sql); 
            $data = array();
            try {
                $stmt->execute();

                // set the resulting array to associative
                $data = $stmt->setFetchMode(PDO::FETCH_ASSOC); 
                $data = $stmt->fetchAll();
                $this->printLn("$sql");
            } catch (Exception $e) {
                $this->printLn("Database, Table or Column doesn't exist!");
                return 1;
            }

            $dataCount = count($data);        
            if ($dataCount==0) {
                $this->printLn("No records!");
            }else{
                $this->printLn("record count ".$dataCount);
                $this->printLn("Successfully retrieved data!");
            }
            return $data;
        }

        function searchRowsAsJSON($tablename, $field, $value){
            $data = $this->searchRows($tablename, $field, $value);
            $data = json_encode($data);
            return $data;
        }

        function getLastId(){
            return $this->conn->lastInsertId();
        }

        function customSelectQuery($sql){
            $stmt = $this->conn->prepare($sql); 
            $data = array();
            try {
                $stmt->execute();

                // set the resulting array to associative
                $data = $stmt->setFetchMode(PDO::FETCH_ASSOC); 
                $data = $stmt->fetchAll();
                $this->printLn("$sql");
            } catch (Exception $e) {
                $this->printLn("Database, Table or Column doesn't exist!");
                return 1;
            }
            return $data;
        }

        function execute($sql){
            try {
                $this->conn->exec($sql); 
                $this->printLn("$sql");
            } catch (Exception $e) {
                $this->printLn("Database, Table or Column doesn't exist!");
                return 1;
            }
            return 0;
        }

        function close(){
            // closes the connection
            $this->printLn("Closing connection...");
            $this->conn = NULL;
            $this->printLn("CLosed successfully!");
        }


    }
 ?>