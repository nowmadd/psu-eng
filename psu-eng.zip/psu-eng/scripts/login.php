<?php 
	include "database.php";
	
	$tableName = "accounts";
	$fields = array(
		"account_id INT(10) AUTO_INCREMENT PRIMARY KEY",
		"username VARCHAR(30)",
		"password VARCHAR(100)",
		"f_name VARCHAR(100)",
		"m_name VARCHAR(100)",
		"l_name VARCHAR(100)",
		"campus VARCHAR(100)",
		"type VARCHAR(100)",
	);
	$db->createTable($tableName, $fields);
	
	$user_username = isset($_POST['username'])?$_POST['username']:"";
	$user_password = isset($_POST['password'])?$_POST['password']:"";
	$condition=array(
		"username"=>$user_username,
		"password"=>md5($user_password)
	);
	$data = $db->getRows($tableName, $condition); /*return normal associative array*/
	$result = 1;
	if (count($data)==0) {
		// echo "no account";
		$data = $db->getRows($tableName, array("username"=>"admin","password"=>md5("12345"))); /*return normal associative array*/
		if ($user_username=="admin" and md5($user_password) == md5("12345")) {
			// echo "inserting new admin account";
			// if no account existing, create a default admin account
			$values = array(
				"username"=>"admin",
				"password"=>md5("12345"),
				"f_name"=>"admin",
				"m_name"=>"admin",
				"l_name"=>"admin",
				"campus"=>"Lingayen",
				"type"=>"admin",
			);
			$result = $db->insertRow($tableName,$values);
			$userObj = array("user"=>"admin","id"=>1,"type"=>"Admin");
			echo json_encode($userObj);
		}else{
			echo 1;
		}
	}else if(count($data)==1){
		$userObj = array("user"=>$data[0]["username"],"id"=>$data[0]["account_id"],"type"=>$data[0]["type"]);
		echo json_encode($userObj);
	}else{
		echo 1;
	}

 ?>