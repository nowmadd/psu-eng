<?php 
	include "database.php";
	
	$tableName = "accounts";
	$fields = array(
		"account_id INT(10) AUTO_INCREMENT PRIMARY KEY",
		"username VARCHAR(30)",
		"password VARCHAR(100)",
		"f_name VARCHAR(100)",
		"m_name VARCHAR(100)",
		"l_name VARCHAR(100)",
		"campus VARCHAR(100)",
		"type VARCHAR(100)",
	);
	$db->createTable($tableName, $fields);
	
	$username = isset($_POST['username'])?$_POST['username']:"";
	$password = isset($_POST['password'])?$_POST['password']:"";
	$f_name = isset($_POST['f_name'])?$_POST['f_name']:"";
	$m_name = isset($_POST['m_name'])?$_POST['m_name']:"";
	$l_name = isset($_POST['l_name'])?$_POST['l_name']:"";
	$campus = isset($_POST['campus'])?$_POST['campus']:"";
	$type = isset($_POST['type'])?$_POST['type']:"";
	// print_r($_POST);
	$values = array(
		"username"=>$username,
		"password"=>md5($password),
		"f_name"=>$f_name,
		"m_name"=>$m_name,
		"l_name"=>$l_name,
		"campus"=>$campus,
		"type"=>$type,
	);
	$result = $db->insertRow($tableName,$values);
	$id = $db->getLastId();
	if ($result==0) {
		$name = $f_name." ".$m_name." ".$l_name;
		$userObj = array("user"=>$username,"id"=>$id,"name"=>$name, "campus"=>$campus, "type"=>$type);
		echo json_encode($userObj);
	}else{
		echo 1;
	}
?>