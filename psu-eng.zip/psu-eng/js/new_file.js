var app = new Vue({
	el:".my-content",
	data:{
		proj_id:0,
		proj_name:"",
		start_date:today,
		target_date: monthLater,
		contractor:"",
		campus:"Lingayen",
		duration:"",
		src_fund:"Income",
		model_img:"",
		init_fund:0,
		status:"",
		today: today,
		onload: true,
	},
	mounted: function(){
		if (user.type=="") {
            window.location="login.html";
        }else if (user.type!=="admin") {
        	window.location = "index.html";
        }
        this.getDuration(this.target_date, this.start_date);
	},
	methods:{
      	validate:function(e){
	        this[e.target.name]=e.target.value;
	    },
		getDuration: function(date1, date2){
			this.start_date = date2;
			this.target_date = date1;
			this.duration = date.getDuration(date2, date1)+ " day(s)";
		},
		showImg: function(building){
			return "background-image: url("+building+")";
		},	
		fileInput: function(){
	        var file_form = $("#file-form")[0];
	        var files = file_form[0].files;
	        var reader = new FileReader();

	        if (files.length>1) {
	          $("#fileLabel").text(files.length +" files selected.");
	        }else{
	          $("#fileLabel").text(files[0].name);
	        }

	        reader.onload = function (e) {
	            $("#thumbnail")[0].src = e.target.result;
	        };

	        reader.readAsDataURL(files[0]);
	    },
		save: function(){
			var file_form = document.querySelector("#file-form");
		    var formData = new FormData(file_form);		    
	        var files = file_form[0].files;	    

        	formData.append("start_date", this.start_date);
        	formData.append("target_date", this.target_date);
			var maxSize = 1994000;
			var fileSizeMax = 0;
			var safeToUpload = true;
			for (var i = 0; i < files.length; i++) {
				if (files[i].size>=maxSize) {
					safeToUpload = false;
					break;
				}
			}
			if (safeToUpload) {
				if (files.length>0 && this.proj_name!="" && this.start_date!="" && this.target_date!="" && this.contractor!="" && this.campus!="" && this.duration!="" && this.src_fund!="" && this.init_fund!="") {
					$.ajax({
				    	url: hosting+"new_file.php", //change url
						type: "POST",
						data:  formData,
						contentType: false,
					    processData:false,
						mimeType:"multipart/form-data",
						success: function(result){
							console.log(result);
							hidePreload();
							if (result==0) {	
						   		file_form.reset();
								showDialog("Successful!", "Project successfully added!", function(){
									window.location= "index.html";
								});
							}else{
								showDialog("Error!", "Your Image is too large! Try again!");
							}
						},
				   	});
				}else{
					showDialog("Invalid!","Fill up the form correctly!");
				}
			}else{
				showDialog("","Image too large in size! Please use image with lower than 1mb.");
			}
		},
	}
});

$("#fileInput").change(function(e){
	var reader = new FileReader();

    if (this.files.length>1) {
      $("#fileLabel").html(this.files.length +" files selected.");
    }else{
      $("#fileLabel").html(this.files[0].name);
    }

	
    reader.onload = function (e) {
        // get loaded data and render thumbnail.
        $("#thumbnail")[0].src = e.target.result;
    };

    // read the image file as a data URL.
    reader.readAsDataURL(this.files[0]);
});